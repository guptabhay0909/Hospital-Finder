/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalfinder;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.ResultSet;
import javax.swing.JTextField;

/**
 *
 * @author AASHEE KHARE
 */
public class HospDet extends javax.swing.JPanel {
   /*public HospDet(){
        try{
        JTextField j1=new JTextField("asasassdasdas     ");
        JTextField j2=new JTextField("asdasdasdasdasdasdasdasdasdasdasdasdasdasdqweewfsdxsadawwsd");
        JTextField j3=new JTextField("qweqwedasesf");
        JTextField j4=new JTextField("asdasfewfsz");
        JTextField j5=new JTextField("asdewwfdaswdasd");
        JTextField j6=new JTextField("asdasfsedfweasdwasdawdseasfdc");
        j1.setSize(225, 30);
        j2.setSize(335, 30);
        j3.setSize(108, 30);
        j4.setSize(108, 30);
        j5.setSize(160, 30);
        j6.setSize(320, 30);
        j1.setMinimumSize(new Dimension(225,30));
        j2.setMinimumSize(new Dimension(225,30));
        j3.setMinimumSize(new Dimension(225,30));
        j4.setMinimumSize(new Dimension(225,30));
        j5.setMinimumSize(new Dimension(225,30));
        j6.setMinimumSize(new Dimension(225,30));
        this.add(j1);
        this.add(j2);
        this.add(j3);
        this.add(j4);
        this.add(j5);
        this.add(j6);
        this.setLayout(new FlowLayout());
        
        
        
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }*/
    public HospDet(ResultSet rs){
        try{
        JTextField j1=new JTextField(rs.getString(1));
        JTextField j2=new JTextField(rs.getString(2));
        JTextField j3=new JTextField(rs.getString(3));
        JTextField j4=new JTextField(rs.getString(4));
        JTextField j5=new JTextField(rs.getString(5));
        JTextField j6=new JTextField(rs.getString(6));
        j1.setSize(225, 30);
        j2.setSize(335, 30);
        j3.setSize(108, 30);
        j4.setSize(108, 30);
        j5.setSize(160, 30);
        j6.setSize(320, 30);
        this.add(j1);
        this.add(j2);
        this.add(j3);
        this.add(j4);
        this.add(j5);
        this.add(j6);
        this.setLayout(new FlowLayout());
        
        
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    /*public static void main(String[] args) {
        HospDet obj=new HospDet();
        obj.setVisible(true);
    }*/
}
