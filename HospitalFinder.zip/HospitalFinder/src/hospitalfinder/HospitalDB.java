/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalfinder;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author AASHEE KHARE
 */
public class HospitalDB {
    Connection con;
    Statement stm;
    ResultSet rs;
    public HospitalDB()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/hospital","root","tiger");
            stm=con.createStatement();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
        
    }
}
